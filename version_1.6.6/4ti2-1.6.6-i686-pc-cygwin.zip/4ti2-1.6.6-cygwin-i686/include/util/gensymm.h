int gensymm_main(int, char**);
